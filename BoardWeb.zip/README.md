create table users(
    id varchar2(8) PRIMARY key,
    password varchar2(8),
    name varchar2(20),
    role varchar2(5)
);
insert into users values('test', 'test123', '관리자', 'Admin');
insert into users values('test2', 'test123', '홍길동', 'User');
insert into users values('test3', 'test123', '이순신', 'User');

commit;

create table board(
    seq number(5) PRIMARY key,
    title varchar2(200),
    writer varchar2(20),
    content varchar2(2000),
    regdate date default sysdate,
    cnt number(5) DEFAULT 0
);

insert into board(seq, title, writer, content) 
values(1,'가입인사', '관리자', '잘 부탁드립니다');

insert into board(seq, title, writer, content) 
values(2,'가입인사2', '관리자', '잘 부탁드립니다');

insert into board(seq, title, writer, content) 
values(3,'가입인사3', '관리자', '잘 부탁드립니다');


