package com.springbook.biz.common;

import org.aspectj.lang.ProceedingJoinPoint;

public class AroundAdvice {
	public Object aroundLog(ProceedingJoinPoint pjp) throws Throwable {
		System.out.println("비즈니스 메소드 수행전");
		Object returnObj = pjp.proceed();
		System.out.println("비즈니스 메소드 수행후");
		
		return returnObj;
	}
}
