package com.springbook.biz.user;

import lombok.Data;

@Data
public class UserVO {
	private String id;
	String password, name, role;
	
}
